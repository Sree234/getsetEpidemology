import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import {MediaMatcher,} from '@angular/cdk/layout';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule, Http,Response} from '@angular/http';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  mobileQuery: MediaQueryList;
  fillerNav = Array(50).fill(0).map((_, i) => `Nav Item ${i + 1}`);
  private _mobileQueryListener: () => void;
  constructor(media: MediaMatcher,changeDetectorRef: ChangeDetectorRef,) { 
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnInit() {
  }

}
