import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import {GetSetService} from '../../../services/getset.service';
import {OtpModel} from '../../../models/OtpModel';
import{Validators,FormBuilder,FormGroup,FormControl} from '@angular/forms';


@Component({
  selector: 'app-textotp',
  templateUrl: './textotp.component.html',
  styleUrls: ['./textotp.component.css'],
  providers:[GetSetService,FormBuilder]
})
export class TextotpComponent implements OnInit {
   otpModel:OtpModel;
   complexForm:FormGroup;
   userOtpvalue:string;

  constructor(private router: Router,private otpService: GetSetService, private fb:FormBuilder) { 
    this.complexForm = fb.group({
      // To add a validator, we must first convert the string value into an array. The first item in the array is the default value if any, then the next item in the array is the validator. Here we are adding a required validator meaning that the firstName attribute must have a value in it.
      //'eMail' : [null,  Validators.compose([Validators.required])],
      'mobileNumber' : [null, Validators.compose([Validators.required])],
      'otp':[null,  Validators.compose([Validators.required])]
     
    });
  
  }
  submit(){
    this.router.navigate(['/changepassword']);
  }
  ngOnInit() {
    this.userOtpvalue= localStorage.getItem('otptextValue');;
    this.complexForm.controls['mobileNumber'].setValue(this.userOtpvalue);
   


    var OtpTextModel = {
	
       'phonNumber': "7032311679",
      
     'generatedOtp':"",
      
      'textMessage':""
     
     
      }
   
    
   

  }

  textOtp(value){
    console.log(value);
    this.otpModel=value;
    console.log(this.otpModel);

    this.otpService.otpText(this.otpModel).subscribe(data => console.log(data))


  }

  validation_messages = {
   
    'mobileNumber': [
      { type: 'required', message: 'Mobile Number is required' },
     
    ],
    'otp': [
      { type: 'required', message: 'Mobile Number is required' },
     
    ]
   
    }
}
