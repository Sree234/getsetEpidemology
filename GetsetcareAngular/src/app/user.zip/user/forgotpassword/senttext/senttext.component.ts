import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import {GetSetService} from '../../../services/getset.service';
import {OtpModel} from '../../../models/OtpModel';
import{Validators,FormBuilder,FormGroup,FormControl} from '@angular/forms';

@Component({
  selector: 'app-senttext',
  templateUrl: './senttext.component.html',
  styleUrls: ['./senttext.component.css'],
  providers:[GetSetService,FormBuilder]
})
export class SenttextComponent implements OnInit {
  otpModeldata = new OtpModel;
  complexForm:FormGroup;
  @Input() tstatus:boolean = false;
  @Output() sendText: EventEmitter<boolean> =   new EventEmitter();
  
  constructor(private router: Router,private otpService: GetSetService, private fb:FormBuilder) { 
   
    this.complexForm = fb.group({
      // To add a validator, we must first convert the string value into an array. The first item in the array is the default value if any, then the next item in the array is the validator. Here we are adding a required validator meaning that the firstName attribute must have a value in it.
     
      //'email':new FormControl(),
      'mobileNumber':['', Validators.compose([ Validators.required, Validators.pattern('^[0-9]+$')])],
      // 'dob':new FormControl()
    });
  }
  // sendtext(){
  //   this.tstatus = true;
  //   this.sendText.emit(this.tstatus);
  // }
 

  ngOnInit() {


  }
  
  otptext(value){
    localStorage.removeItem('otptextValue');
    this.tstatus = true;
    this.sendText.emit(this.tstatus);
    console.log(value);
    value.mobileNumber = '91'+ value.mobileNumber;
    this.otpModeldata.phoneNumber = value.mobileNumber;
    localStorage.setItem('otptextValue', this.otpModeldata.phoneNumber);
    // this.otpModeldata.textMessage=value.dob;
     console.log(this.otpModeldata);
    //this.otpService.otpText(this.otpModeldata).subscribe(data => console.log(data))


}
validation_messages = {
   
  'mobileNumber': [
    { type: 'required', message: 'Mobile Number is required' },
    { type: 'pattern', message: 'Enter a valid Mobile Number ' }
  ]
 
  }
}
