import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import {GetSetService} from '../../services/getset.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import {LoginModel } from '../../models/loginmodel';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [FormBuilder, GetSetService]
})
export class RegisterComponent implements OnInit {
checkemail:boolean = true;
complexForm:FormGroup;
loginvalidation :LoginModel;
emailnotavailable :boolean = false;
emailavailable :boolean = false;
  constructor(private router: Router,private addseService:GetSetService, private fb:FormBuilder) { 
    

    this.complexForm = fb.group({
      // To add a validator, we must first convert the string value into an array. The first item in the array is the default value if any, then the next item in the array is the validator. Here we are adding a required validator meaning that the firstName attribute must have a value in it.
      'eMail' : [null,  Validators.compose([Validators.required])],
      firstName:new FormControl()
     
    });


    

    
  
  }

  signup(id){
    console.log(id);



  }

  checkEmail(val){ 
    console.log(val.eMail);
    
    this.loginvalidation = val;
    console.log(this.loginvalidation);
    
    //this.login.userName=val.emailid;
if(val.eMail != ''){
  this.addseService.signup(this.loginvalidation).subscribe(
    data => {
  
        console.log("Login data");
        console.log(data);        
if(data.status== true){
this.checkemail = false;
this.emailnotavailable =false;
this.emailavailable =true;
}else{
this.checkemail = false;
this.emailnotavailable =true;
 this.emailavailable =false;
}
    
   }
   );
}
    
    
    
    
  }
  regwithemail(){ 

    var signUpModel ={
         'email': 'mani',
         
       }
    
       
    //this.router.navigate(['/user/userregistration']);
  } 
  regwithoutemail(){
    this.router.navigate(['/user/userregistration']);
  }
  ngOnInit() {


  }

}
