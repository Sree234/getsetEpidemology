import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import {UserComponent } from './user.component';
import { SentemailComponent } from './forgotpassword/sentemail/sentemail.component';
import { SenttextComponent } from './forgotpassword/senttext/senttext.component';
import {userrouting } from './user.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
} from '@angular/material';  
import { QrscanComponent } from './qrscan/qrscan.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { EmailotpComponent } from './forgotpassword/emailotp/emailotp.component';
import { TextotpComponent } from './forgotpassword/textotp/textotp.component';
import { ChangepasswordComponent } from './forgotpassword/changepassword/changepassword.component';
import { RegisterComponent } from './register/register.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';
import { ServiceComponent } from './service/service.component';
@NgModule({
  imports: [
    FormsModule, ReactiveFormsModule,
    CommonModule,userrouting,
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,  
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule, 
  ],
  declarations: [
    UserComponent,LoginComponent, QrscanComponent, ForgotpasswordComponent,
    SentemailComponent, SenttextComponent,EmailotpComponent, TextotpComponent, ChangepasswordComponent, 
    RegisterComponent, UserregistrationComponent, ServiceComponent,
  ]
})
export class UserModule { }
