import { Component, OnInit } from '@angular/core';
import {GetSetService} from '../../services/getset.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import {registerModel} from '../../models/registerModel';

@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.css'],
  providers: [FormBuilder, GetSetService]
  
})
export class UserregistrationComponent implements OnInit {
Countries: registerModel;
userRegistration:registerModel;
userRegistrationForm:FormGroup;
  constructor(private addseService:GetSetService, private fb:FormBuilder) {
    this.userRegistrationForm = fb.group({
      // To add a validator, we must first convert the string value into an array. The first item in the array is the default value if any, then the next item in the array is the validator. Here we are adding a required validator meaning that the firstName attribute must have a value in it.
     
     
     
      'firstName' : [null,  Validators.compose([Validators.required])],
      'lastName' : [null,  Validators.compose([Validators.required])],
      'dateOfBirth' : [null,  Validators.compose([Validators.required])],
      'gender' : [null,  Validators.compose([Validators.required])],
      'mobileNumber' : [null,  Validators.compose([Validators.required])],
      'eMail' : [null,  Validators.compose([Validators.required])],
      'country' : [null, Validators.compose([Validators.required])],
      'userName' : [null,  Validators.compose([Validators.required])],
      'createPassword' : [null,  Validators.compose([Validators.required])],
      'reEnterPassword': [null,  Validators.compose([Validators.required])],
     
    });   
    this.addseService.countryList().subscribe(
      data => { 
        
       this.Countries =data;
        console.log("countries"); console.log(this.Countries)});
        
   }

   selectCountry(value){
     console.log("Selected Country");
     console.log(value.country);

   }

   registerUser(value){
     console.log(value);
    this.userRegistration=value;
    console.log(this.userRegistration);

   
     this.addseService.registerUser(this.userRegistration).subscribe(data =>console.log (data))

   }
  ngOnInit() {
  }

}
