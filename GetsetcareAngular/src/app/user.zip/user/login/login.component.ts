import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import {MediaMatcher,} from '@angular/cdk/layout';
import { RouterModule, Routes, Router } from '@angular/router';
import { HttpModule, Http,Response} from '@angular/http';
import {GetSetService} from '../../services/getset.service';
import {FormGroup,FormBuilder,FormControl,Validators} from '@angular/forms';
import {LoginModel } from '../../models/loginmodel';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[GetSetService,FormBuilder]
})
export class LoginComponent implements OnInit {
  complexForm:FormGroup;
  loginForm :LoginModel;
emailnotavailable :boolean = false;
emailavailable :boolean = false;



  constructor(private mainService:GetSetService,private router:Router,private fb:FormBuilder ){
    this.complexForm = fb.group({
      // To add a validator, we must first convert the string value into an array. The first item in the array is the default value if any, then the next item in the array is the validator. Here we are adding a required validator meaning that the firstName attribute must have a value in it.
      'eMail' : [null,  Validators.compose([Validators.required])],
     
    });
  
  }

  checkEmail(val){
    console.log(val)
    this.loginForm = val;
    console.log(this.loginForm);


  }
  
  ngOnInit() {

    
    // var resp ={
    //   'userId': "nagamani",
    //   'password': 'uec123'
    // }
    // console.log("data");
    // this.addseService.hi(resp).subscribe(
    //   data => {
      
    //       console.log("Login data");
    //       console.log(data);          
        
    //  }
    //  );
  }

}
