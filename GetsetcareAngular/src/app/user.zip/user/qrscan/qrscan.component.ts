import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qrscan',
  templateUrl: './qrscan.component.html',
  styleUrls: ['./qrscan.component.css']
})
export class QrscanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
